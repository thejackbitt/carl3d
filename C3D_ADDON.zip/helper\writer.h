#include <windows.h>

int write(char* data, char* view, const size_t bufferSize);