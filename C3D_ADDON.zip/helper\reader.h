#include <windows.h>

int read(const char* bufferName, const size_t bufferSize, const char* bufferName2, const size_t bufferSize2);